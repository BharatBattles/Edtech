export interface Video {
  id: string;
  rank: number;
  title: string;
  channel: string;
  thumbnail: string;
  views: string;
  duration: string;
  tags: string[];
  subject: string;
  classLevel: string;
  score: number; // calculated rank score
}

export const subjects = [
  "Mathematics",
  "Physics",
  "Chemistry",
  "Biology",
  "Computer Science",
  "History",
  "Literature"
];

export const classLevels = [
  "Grade 9",
  "Grade 10",
  "Grade 11",
  "Grade 12",
  "Undergraduate"
];

// Helper to generate consistent mock data
const generateMockVideos = (): Video[] => {
  const videos: Video[] = [];
  let idCounter = 1;

  const templates = [
    { title: "Complete Calculus in 10 Hours", subject: "Mathematics", tags: ["Calculus", "Exam Prep"] },
    { title: "Quantum Physics Explained", subject: "Physics", tags: ["Quantum", "Theory"] },
    { title: "Organic Chemistry Basics", subject: "Chemistry", tags: ["Organic", "Basics"] },
    { title: "Cell Structure & Function", subject: "Biology", tags: ["Cells", "Anatomy"] },
    { title: "Data Structures Crash Course", subject: "Computer Science", tags: ["Algorithms", "Coding"] },
    { title: "World War II Documentary", subject: "History", tags: ["WWII", "Modern History"] },
    { title: "Shakespeare: Hamlet Analysis", subject: "Literature", tags: ["Drama", "Analysis"] },
    { title: "Algebra Linear Equations", subject: "Mathematics", tags: ["Algebra", "Basics"] },
    { title: "Newton's Laws of Motion", subject: "Physics", tags: ["Mechanics", "Forces"] },
    { title: "Periodic Table Trends", subject: "Chemistry", tags: ["Inorganic", "Elements"] },
  ];

  const channels = ["Khan Academy", "CrashCourse", "Organic Chemistry Tutor", "3Blue1Brown", "Veritasium", "FreeCodeCamp", "History Channel", "Ted-Ed"];

  classLevels.forEach(level => {
    templates.forEach((template, index) => {
      // Create a few variations per subject/class
      for (let i = 0; i < 3; i++) {
        const score = 9.8 - (i * 0.5) - (Math.random() * 0.3);
        videos.push({
          id: `vid-${idCounter++}`,
          rank: i + 1, // This will be dynamic based on filtering usually, but we mock it here
          title: `${template.title} - ${level} ${i > 0 ? `(Part ${i+1})` : ''}`,
          channel: channels[Math.floor(Math.random() * channels.length)],
          thumbnail: `https://images.unsplash.com/photo-${1500000000000 + idCounter}?w=800&auto=format&fit=crop&q=60`, // Random unsplash placeholder
          views: `${(Math.random() * 5 + 0.5).toFixed(1)}M views`,
          duration: `${Math.floor(Math.random() * 20 + 10)}:${Math.floor(Math.random() * 50 + 10)}`,
          tags: [...template.tags, level],
          subject: template.subject,
          classLevel: level,
          score: parseFloat(score.toFixed(1))
        });
      }
    });
  });

  return videos;
};

export const mockVideos = generateMockVideos();
