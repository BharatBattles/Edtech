import { Video } from "@shared/schema";
import { Play, Star, Clock, Eye, TrendingUp } from "lucide-react";
import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";

interface VideoCardProps {
  video: Video;
  index: number;
}

export function VideoCard({ video, index }: VideoCardProps) {
  const youtubeUrl = `https://www.youtube.com/watch?v=${video.videoId}`;
  
  const getRankColor = (rank: number) => {
    if (rank === 1) return 'from-yellow-400 to-yellow-600 text-white';
    if (rank === 2) return 'from-slate-300 to-slate-500 text-white';
    if (rank === 3) return 'from-orange-400 to-orange-600 text-white';
    return 'from-primary to-blue-600 text-white';
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: index * 0.05 }}
    >
      <a 
        href={youtubeUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="block group"
      >
        <Card className="overflow-hidden hover:shadow-lg transition-all duration-300 border-border/40 bg-white hover:border-primary/30">
          <div className="flex flex-col sm:flex-row gap-4 p-4 sm:p-5">
            {/* Thumbnail Section */}
            <div 
              className="relative shrink-0 w-full sm:w-[320px] aspect-video rounded-lg overflow-hidden bg-muted shadow-md"
              data-testid={`video-thumbnail-${video.videoId}`}
            >
              {/* Rank Badge - Top Left */}
              <div className={`absolute top-3 left-3 z-10 w-12 h-12 flex items-center justify-center font-heading font-bold text-lg bg-gradient-to-br ${getRankColor(video.rank)} shadow-lg rounded-lg`}
                data-testid={`video-rank-${video.videoId}`}
              >
                #{video.rank}
              </div>
              
              <img 
                src={video.thumbnail}
                alt={video.title}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
              />
              
              <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <div className="bg-white/90 backdrop-blur-sm p-4 rounded-full shadow-lg">
                  <Play className="w-6 h-6 text-primary fill-primary" />
                </div>
              </div>

              {/* Duration Badge */}
              <div className="absolute bottom-3 right-3 bg-black/80 text-white text-xs px-2.5 py-1.5 rounded-md font-medium flex items-center gap-1 backdrop-blur-sm">
                <Clock className="w-3 h-3" /> {video.duration}
              </div>
            </div>

            {/* Content Section */}
            <div className="flex-1 flex flex-col justify-between py-1">
              <div>
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="flex gap-2 flex-wrap">
                    <Badge variant="secondary" className="text-xs font-semibold text-primary bg-primary/10 hover:bg-primary/15 border-none">
                      {video.subject}
                    </Badge>
                    <Badge variant="outline" className="text-xs font-medium text-muted-foreground border-border/60">
                      {video.classLevel}
                    </Badge>
                  </div>
                </div>
                
                <h3 className="text-base sm:text-lg font-heading font-bold text-foreground leading-snug mb-2 group-hover:text-primary transition-colors line-clamp-2" data-testid={`video-title-${video.videoId}`}>
                  {video.title}
                </h3>
                
                <p className="text-muted-foreground text-sm font-medium mb-4" data-testid={`video-channel-${video.videoId}`}>
                  {video.channel}
                </p>

                {/* Description */}
                <p className="text-muted-foreground text-sm line-clamp-2 mb-4 leading-relaxed">
                  {video.description.substring(0, 120)}...
                </p>

                {/* Tags */}
                <div className="flex flex-wrap gap-1.5">
                  {video.tags.slice(0, 2).map(tag => (
                    <span key={tag} className="text-xs text-primary/70 bg-primary/5 px-2.5 py-1 rounded-full font-medium">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>

              {/* Footer Stats */}
              <div className="flex items-center justify-between mt-4 pt-4 border-t border-border/40">
                <div className="flex items-center gap-5 text-sm">
                  <span className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors" data-testid={`video-views-${video.videoId}`}>
                    <Eye className="w-4 h-4" /> <span className="font-medium">{video.views}</span>
                  </span>
                </div>
                
                <div className="flex items-center gap-2 text-accent font-bold text-sm bg-accent/10 px-3 py-1.5 rounded-lg" data-testid={`video-score-${video.videoId}`}>
                  <Star className="w-4 h-4 fill-accent" />
                  <span>{video.score.toFixed(1)}</span>
                </div>
              </div>
            </div>
          </div>
        </Card>
      </a>
    </motion.div>
  );
}
