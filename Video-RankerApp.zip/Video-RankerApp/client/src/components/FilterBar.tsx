import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { subjects, classLevels } from "@/lib/mockData";
import { Search } from "lucide-react";

interface FilterBarProps {
  selectedSubject: string;
  setSelectedSubject: (val: string) => void;
  selectedClass: string;
  setSelectedClass: (val: string) => void;
}

export function FilterBar({ 
  selectedSubject, 
  setSelectedSubject,
  selectedClass,
  setSelectedClass
}: FilterBarProps) {
  return (
    <div className="sticky top-0 z-40 w-full bg-white/95 backdrop-blur-sm border-b border-border shadow-sm">
      <div className="container mx-auto max-w-7xl px-4 py-4">
        <div className="flex flex-col sm:flex-row items-center gap-4">
          <div className="flex items-center gap-2 text-foreground font-heading font-semibold text-sm">
            <Search className="w-4 h-4 text-primary" />
            <span>Find Videos</span>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto sm:ml-auto">
            <Select value={selectedSubject} onValueChange={setSelectedSubject}>
              <SelectTrigger className="w-full sm:w-[180px] bg-white border-border shadow-sm hover:border-primary/50 transition-colors">
                <SelectValue placeholder="Subject" />
              </SelectTrigger>
              <SelectContent>
                {subjects.map((sub) => (
                  <SelectItem key={sub} value={sub}>{sub}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={selectedClass} onValueChange={setSelectedClass}>
              <SelectTrigger className="w-full sm:w-[180px] bg-white border-border shadow-sm hover:border-primary/50 transition-colors">
                <SelectValue placeholder="Class Level" />
              </SelectTrigger>
              <SelectContent>
                {classLevels.map((lvl) => (
                  <SelectItem key={lvl} value={lvl}>{lvl}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>
    </div>
  );
}
