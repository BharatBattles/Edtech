import { useState } from "react";
import { subjects, classLevels } from "@/lib/mockData";
import { VideoCard } from "@/components/VideoCard";
import { FilterBar } from "@/components/FilterBar";
import { Sparkles, Search, Loader2, BookOpen } from "lucide-react";
import { motion } from "framer-motion";
import { useQuery } from "@tanstack/react-query";
import type { Video } from "@shared/schema";

async function searchVideos(subject: string, classLevel: string): Promise<Video[]> {
  const response = await fetch('/api/videos/search', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ subject, classLevel })
  });

  if (!response.ok) {
    throw new Error('Failed to search videos');
  }

  return response.json();
}

export default function Home() {
  const [selectedSubject, setSelectedSubject] = useState(subjects[0]);
  const [selectedClass, setSelectedClass] = useState(classLevels[0]);

  const { data: videos = [], isLoading, error } = useQuery({
    queryKey: ['videos', selectedSubject, selectedClass],
    queryFn: () => searchVideos(selectedSubject, selectedClass),
  });

  return (
    <div className="min-h-screen bg-gradient-to-b from-white via-slate-50 to-white font-sans text-foreground">
      {/* Hero Section */}
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/5 via-accent/5 to-primary/5"></div>
        <div className="absolute top-0 right-0 w-96 h-96 bg-primary/5 rounded-full blur-3xl -translate-y-1/2"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-accent/5 rounded-full blur-3xl translate-y-1/2"></div>
        
        <div className="container relative mx-auto max-w-7xl px-4 py-20 sm:py-28">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center mb-12"
          >
            <div className="inline-flex items-center justify-center gap-2 mb-6 px-4 py-2 bg-accent/10 rounded-full border border-accent/20">
              <Sparkles className="w-4 h-4 text-accent" />
              <span className="text-sm font-semibold text-accent">AI-Powered Learning</span>
            </div>
            
            <h1 className="text-5xl sm:text-6xl font-heading font-bold text-foreground mb-6 leading-tight">
              Find Your Perfect<br /><span className="text-primary">Educational Videos</span>
            </h1>
            
            <p className="text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed mb-8 font-light">
              Discover and rank the best YouTube educational content tailored to your subject and class level. Powered by AI to find videos that truly help you learn.
            </p>

            <div className="flex items-center justify-center gap-8 text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-primary"></div>
                <span className="font-medium">{subjects.length}+ Subjects</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-accent"></div>
                <span className="font-medium">All Levels</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-primary/60"></div>
                <span className="font-medium">AI Ranked</span>
              </div>
            </div>
          </motion.div>
        </div>
      </div>

      <FilterBar 
        selectedSubject={selectedSubject}
        setSelectedSubject={setSelectedSubject}
        selectedClass={selectedClass}
        setSelectedClass={setSelectedClass}
      />

      <main className="container mx-auto max-w-7xl px-4 py-12">
        {/* Results Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <BookOpen className="w-6 h-6 text-primary" />
            <h2 className="text-3xl font-heading font-bold text-foreground">
              Top Recommended Videos
            </h2>
          </div>
          <p className="text-muted-foreground">
            {selectedSubject} • {selectedClass} {!isLoading && videos.length > 0 && `• ${videos.length} results`}
          </p>
        </div>

        {/* Loading State */}
        {isLoading && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex flex-col items-center justify-center py-32"
          >
            <div className="relative w-16 h-16 mb-6">
              <Loader2 className="w-full h-full text-primary animate-spin" />
            </div>
            <h3 className="text-xl font-heading font-bold text-foreground mb-2">Finding the best videos...</h3>
            <p className="text-muted-foreground text-center max-w-sm">Our AI is analyzing and ranking educational content for you</p>
          </motion.div>
        )}

        {/* Error State */}
        {error && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-20 bg-destructive/5 rounded-2xl border border-destructive/20"
          >
            <Search className="w-12 h-12 text-destructive/60 mx-auto mb-4" />
            <h3 className="text-xl font-heading font-bold text-foreground mb-2">Unable to load videos</h3>
            <p className="text-muted-foreground">Please try again or select different filters</p>
          </motion.div>
        )}

        {/* Results */}
        {!isLoading && !error && (
          <div className="space-y-4">
            {videos.length > 0 ? (
              videos.map((video, index) => (
                <VideoCard key={video.id} video={video} index={index} />
              ))
            ) : (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-center py-20 bg-secondary/30 rounded-2xl border border-border/60"
              >
                <Search className="w-12 h-12 text-muted-foreground/40 mx-auto mb-4" />
                <h3 className="text-lg font-heading font-bold text-foreground mb-2">No videos found</h3>
                <p className="text-muted-foreground">Try adjusting your subject or class level filters</p>
              </motion.div>
            )}
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-border/40 bg-white/50 backdrop-blur-sm mt-20">
        <div className="container mx-auto max-w-7xl px-4 py-12 text-center text-muted-foreground text-sm">
          <p>EduRank © 2024 • Helping students find the best educational content</p>
        </div>
      </footer>
    </div>
  );
}
