// No storage needed for this app - we fetch videos on demand from YouTube API
export interface IStorage {}

export class MemStorage implements IStorage {
  constructor() {}
}

export const storage = new MemStorage();
