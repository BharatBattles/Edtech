import type { Express } from "express";
import type { Server } from "http";
import { searchVideosSchema } from "@shared/schema";
import { z } from "zod";

const YOUTUBE_API_KEY = process.env.YOUTUBE_API_KEY;
const OPENAI_API_KEY = process.env.OPENAI_API_KEY;

interface YouTubeVideo {
  id: { videoId: string };
  snippet: {
    title: string;
    description: string;
    channelTitle: string;
    thumbnails: {
      high: { url: string };
    };
  };
}

interface YouTubeSearchResponse {
  items: YouTubeVideo[];
}

interface VideoDetails {
  items: Array<{
    contentDetails: { duration: string };
    statistics: { viewCount: string };
  }>;
}

async function searchYouTube(query: string, maxResults = 20): Promise<YouTubeVideo[]> {
  const url = `https://www.googleapis.com/youtube/v3/search?part=snippet&q=${encodeURIComponent(query)}&type=video&maxResults=${maxResults}&key=${YOUTUBE_API_KEY}`;
  
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`YouTube API error: ${response.statusText}`);
  }
  
  const data: YouTubeSearchResponse = await response.json();
  return data.items || [];
}

async function getVideoDetails(videoIds: string[]): Promise<VideoDetails> {
  const url = `https://www.googleapis.com/youtube/v3/videos?part=contentDetails,statistics&id=${videoIds.join(',')}&key=${YOUTUBE_API_KEY}`;
  
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`YouTube API error: ${response.statusText}`);
  }
  
  return await response.json();
}

function parseDuration(duration: string): string {
  const match = duration.match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/);
  if (!match) return "0:00";
  
  const hours = parseInt(match[1] || "0");
  const minutes = parseInt(match[2] || "0");
  const seconds = parseInt(match[3] || "0");
  
  if (hours > 0) {
    return `${hours}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  }
  return `${minutes}:${seconds.toString().padStart(2, '0')}`;
}

function formatViews(views: string): string {
  const num = parseInt(views);
  if (num >= 1000000) {
    return `${(num / 1000000).toFixed(1)}M views`;
  } else if (num >= 1000) {
    return `${(num / 1000).toFixed(1)}K views`;
  }
  return `${num} views`;
}

async function rankVideosWithOpenAI(videos: any[], subject: string, classLevel: string): Promise<any[]> {
  if (!OPENAI_API_KEY) {
    return videos.map((v, i) => ({ ...v, score: 9.5 - (i * 0.3), rank: i + 1 }));
  }

  const videoDescriptions = videos.map((v, i) => 
    `${i + 1}. Title: "${v.title}"\n   Channel: ${v.channel}\n   Description: ${v.description.substring(0, 200)}`
  ).join('\n\n');

  const prompt = `You are an educational content curator. Rank these YouTube videos for "${subject}" at "${classLevel}" level based on educational quality, clarity, and reliability.

Videos to rank:
${videoDescriptions}

Provide a JSON array with rankings. Each item should have:
- videoIndex: the original video number (1-based)
- score: a score from 1-10 (10 being best)
- reasoning: brief explanation (max 50 words)

Return ONLY valid JSON array, no other text.`;

  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${OPENAI_API_KEY}`
      },
      body: JSON.stringify({
        model: 'gpt-3.5-turbo',
        messages: [{ role: 'user', content: prompt }],
        temperature: 0.3,
        max_tokens: 1000
      })
    });

    if (!response.ok) {
      console.error('OpenAI API error:', response.statusText);
      return videos.map((v, i) => ({ ...v, score: 9.5 - (i * 0.3), rank: i + 1 }));
    }

    const data = await response.json();
    const rankings = JSON.parse(data.choices[0].message.content);

    const rankedVideos = rankings
      .sort((a: any, b: any) => b.score - a.score)
      .map((ranking: any, rank: number) => ({
        ...videos[ranking.videoIndex - 1],
        score: ranking.score,
        rank: rank + 1
      }));

    return rankedVideos;
  } catch (error) {
    console.error('Error ranking videos with OpenAI:', error);
    return videos.map((v, i) => ({ ...v, score: 9.5 - (i * 0.3), rank: i + 1 }));
  }
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  app.post("/api/videos/search", async (req, res) => {
    try {
      const { subject, classLevel } = searchVideosSchema.parse(req.body);
      
      const searchQuery = `${subject} ${classLevel} education tutorial`;
      const youtubeVideos = await searchYouTube(searchQuery, 15);
      
      if (youtubeVideos.length === 0) {
        return res.json([]);
      }

      const videoIds = youtubeVideos.map(v => v.id.videoId);
      const videoDetails = await getVideoDetails(videoIds);

      const videosWithDetails = youtubeVideos.map((video, index) => {
        const details = videoDetails.items[index];
        return {
          id: video.id.videoId,
          videoId: video.id.videoId,
          title: video.snippet.title,
          channel: video.snippet.channelTitle,
          thumbnail: video.snippet.thumbnails.high.url,
          description: video.snippet.description,
          duration: parseDuration(details?.contentDetails?.duration || 'PT0S'),
          views: formatViews(details?.statistics?.viewCount || '0'),
          tags: [subject, classLevel],
          subject,
          classLevel,
          score: 0,
          rank: 0
        };
      });

      const rankedVideos = await rankVideosWithOpenAI(videosWithDetails, subject, classLevel);
      
      res.json(rankedVideos);
    } catch (error) {
      console.error('Error searching videos:', error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: 'Invalid request', details: error.errors });
      } else {
        res.status(500).json({ error: 'Failed to search videos' });
      }
    }
  });

  return httpServer;
}
