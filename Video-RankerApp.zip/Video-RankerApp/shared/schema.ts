import { z } from "zod";

export const searchVideosSchema = z.object({
  subject: z.string(),
  classLevel: z.string(),
});

export type SearchVideosRequest = z.infer<typeof searchVideosSchema>;

export interface Video {
  id: string;
  rank: number;
  title: string;
  channel: string;
  thumbnail: string;
  views: string;
  duration: string;
  tags: string[];
  subject: string;
  classLevel: string;
  score: number;
  videoId: string;
  description: string;
}
